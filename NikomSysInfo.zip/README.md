# NikomSysInfo
For the Swedish BBS-system Nikom. A new version supporting the year 2000. Nice SystemInfo-replacement.

Version 1.2, released 2021-05-10 by Erik Zalitis (erik@zalitis.se)

Warning: GitHub does weird stuff with the CRLFs. I recommend you download the zip-file (NikomSysInfo.zip) for your Amiga instead.